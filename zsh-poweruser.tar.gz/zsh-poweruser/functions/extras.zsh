# functions/extras.zsh
# Source from .zshrc if you want these without cluttering the main file:
#   source "$DOTFILE_DIR/functions/extras.zsh"

# ── Git utilities ──────────────────────────────────────────────────────────────

# Delete all local branches that have been merged into HEAD
git_prune_merged() {
  git branch --merged | grep -vE '^\*|^(\s*)(main|master|develop|dev)$' | xargs -r git branch -d
}

# Interactively check out a branch using fzf
git_fzf_branch() {
  local branch
  branch=$(git branch --all | grep -v HEAD | sed 's/^[* ]*//' | fzf --preview 'git log --oneline -10 {}') \
    && git checkout "$branch"
}

# Show a diff of stash@{n} without applying it
git_stash_show() {
  local n=${1:-0}
  git stash show -p "stash@{$n}"
}

# ── Docker helpers ─────────────────────────────────────────────────────────────

# Remove all stopped containers
docker_clean() {
  docker container prune -f
  docker image prune -f
  docker volume prune -f
}

# Exec into a running container by fuzzy name
docker_exec() {
  local cid
  cid=$(docker ps --format '{{.ID}}\t{{.Names}}\t{{.Image}}' | fzf | awk '{print $1}')
  [[ -n $cid ]] && docker exec -it "$cid" /bin/bash
}

# ── File utilities ─────────────────────────────────────────────────────────────

# Find and open files interactively with fzf + nvim
fe() {
  local file
  file=$(fzf --preview 'head -50 {}') && nvim "$file"
}

# Create a timestamped backup of a file
bak() {
  [[ -z $1 ]] && { echo "usage: bak <file>"; return 1; }
  cp "$1" "${1}.bak.$(date +%Y%m%d_%H%M%S)"
}

# Show the top 10 largest files under the current directory
biggest() {
  find . -type f -printf '%s %p\n' 2>/dev/null | sort -rn | head -10 | awk '{printf "%.1fM\t%s\n", $1/1024/1024, $2}'
}

# ── Network helpers ────────────────────────────────────────────────────────────

# Show public IP
myip() {
  curl -fsSL https://ifconfig.me && echo
}

# Quick curl with timing info
timecurl() {
  curl -w "\ntime_namelookup: %{time_namelookup}\ntime_connect: %{time_connect}\ntime_total: %{time_total}\n" \
    -o /dev/null -s "$@"
}

# ── Process helpers ────────────────────────────────────────────────────────────

# Kill a process by fuzzy name match
fkill() {
  local pid
  pid=$(ps aux | fzf | awk '{print $2}')
  [[ -n $pid ]] && kill "${1:--9}" "$pid"
}

# ── Python helpers ─────────────────────────────────────────────────────────────

# Create a venv and activate it
mkvenv() {
  local name=${1:-.venv}
  python3 -m venv "$name" && source "$name/bin/activate"
}

# Activate the first venv found in . or parent dirs
activate() {
  local dir=$PWD
  while [[ $dir != / ]]; do
    for candidate in "$dir/.venv" "$dir/venv" "$dir/env"; do
      if [[ -f "$candidate/bin/activate" ]]; then
        source "$candidate/bin/activate"
        echo "Activated: $candidate"
        return 0
      fi
    done
    dir=$(dirname "$dir")
  done
  echo "No virtualenv found in current or parent directories."
  return 1
}

# ── Clipboard helpers (Crostini: uses xclip if installed) ─────────────────────

if command -v xclip >/dev/null 2>&1; then
  alias pbcopy='xclip -selection clipboard'
  alias pbpaste='xclip -selection clipboard -o'
elif command -v xsel >/dev/null 2>&1; then
  alias pbcopy='xsel --clipboard --input'
  alias pbpaste='xsel --clipboard --output'
fi
