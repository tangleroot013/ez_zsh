# ==============================================================================
# .zshrc — Chromebook Crostini Power-User Shell
# Repo: https://github.com/<you>/zsh-poweruser
# Order contract:
#   1. Environment
#   2. History
#   3. fpath + compinit (one call, after all fpath mutations)
#   4. Syntax highlighting
#   5. Autosuggestions
#   6. ZVM variable → source vi-mode
#   7. zvm_after_init (history-search bindings, safe from keymap clobber)
#   8. fzf / zoxide / direnv / starship
#   9. Options, aliases, functions, keybindings
# ==============================================================================

# ------------------------------------------------------------------------------
# 1. Environment
# ------------------------------------------------------------------------------
export EDITOR="nvim"
export VISUAL="nvim"
export PAGER="less"
export LESS="-R --use-color"
export LANG="en_US.UTF-8"
export TERM="xterm-256color"
export PATH="$HOME/.local/bin:$HOME/bin:$PATH"

# XDG base dirs (many tools respect these)
export XDG_CONFIG_HOME="$HOME/.config"
export XDG_DATA_HOME="$HOME/.local/share"
export XDG_CACHE_HOME="$HOME/.cache"

# ------------------------------------------------------------------------------
# 2. History
# ------------------------------------------------------------------------------
HISTSIZE=100000
SAVEHIST=100000
HISTFILE="$HOME/.zsh_history"

setopt APPEND_HISTORY
setopt SHARE_HISTORY
setopt HIST_IGNORE_ALL_DUPS
setopt HIST_REDUCE_BLANKS
setopt INC_APPEND_HISTORY
setopt EXTENDED_HISTORY      # timestamps in history file

# ------------------------------------------------------------------------------
# 3. fpath → compinit (single call, all mutations before it)
# ------------------------------------------------------------------------------
# Repo completions dir
[[ -d "${0:A:h}/completions" ]] && fpath+=("${0:A:h}/completions")
# Extra completions (cloned by install.sh)
[[ -d "$HOME/.zsh/plugins/zsh-completions/src" ]] && \
  fpath+=("$HOME/.zsh/plugins/zsh-completions/src")

# System completions
[[ -d /usr/share/zsh/vendor-completions ]] && \
  fpath+=(/usr/share/zsh/vendor-completions)

autoload -Uz compinit
# -C skips the security check on subsequent shells (speeds up startup)
if [[ -n ${ZDOTDIR:-$HOME}/.zcompdump(#qN.mh+24) ]]; then
  compinit
else
  compinit -C
fi

zmodload zsh/complist

zstyle ':completion:*' menu select
zstyle ':completion:*' matcher-list 'm:{a-zA-Z}={A-Za-z}'
zstyle ':completion:*' use-cache on
zstyle ':completion:*' cache-path "$XDG_CACHE_HOME/zsh/compcache"
zstyle ':completion:*' list-colors "${(s.:.)LS_COLORS}"
zstyle ':completion:*:descriptions' format '%F{yellow}-- %d --%f'
zstyle ':completion:*:warnings' format '%F{red}-- no matches for: %d --%f'

# Vi-style navigation inside the completion menu
bindkey -M menuselect 'h' vi-backward-char
bindkey -M menuselect 'l' vi-forward-char
bindkey -M menuselect 'j' vi-down-line-or-history
bindkey -M menuselect 'k' vi-up-line-or-history
bindkey -M menuselect '^M' accept

# ------------------------------------------------------------------------------
# 4. Syntax highlighting (must come before autosuggestions)
# ------------------------------------------------------------------------------
_ZSH_FAST_HL="$HOME/.zsh/plugins/fast-syntax-highlighting/fast-syntax-highlighting.plugin.zsh"
_ZSH_STD_HL="/usr/share/zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh"

if [[ -f $_ZSH_FAST_HL ]]; then
  source "$_ZSH_FAST_HL"
elif [[ -f $_ZSH_STD_HL ]]; then
  source "$_ZSH_STD_HL"
fi
unset _ZSH_FAST_HL _ZSH_STD_HL

# ------------------------------------------------------------------------------
# 5. Autosuggestions
# ------------------------------------------------------------------------------
_ZSH_AUTOSUG="$HOME/.zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh"
_ZSH_AUTOSUG_SYS="/usr/share/zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh"

if [[ -f $_ZSH_AUTOSUG ]]; then
  source "$_ZSH_AUTOSUG"
elif [[ -f $_ZSH_AUTOSUG_SYS ]]; then
  source "$_ZSH_AUTOSUG_SYS"
fi
unset _ZSH_AUTOSUG _ZSH_AUTOSUG_SYS

ZSH_AUTOSUGGEST_STRATEGY=(history completion)
ZSH_AUTOSUGGEST_BUFFER_MAX_SIZE=20
ZSH_AUTOSUGGEST_USE_ASYNC=1

# ------------------------------------------------------------------------------
# 6. Vi mode — variable set BEFORE source (read at init time)
# ------------------------------------------------------------------------------
_ZSH_VI_MODE="$HOME/.zsh/plugins/zsh-vi-mode/zsh-vi-mode.plugin.zsh"

if [[ -f $_ZSH_VI_MODE ]]; then
  ZVM_VI_INSERT_ESCAPE_BINDKEY=jk        # jk exits insert mode
  ZVM_LINE_INIT_MODE=$ZVM_MODE_INSERT    # start in insert (sane default)
  ZVM_CURSOR_STYLE_ENABLED=true
  source "$_ZSH_VI_MODE"
fi
unset _ZSH_VI_MODE

# ------------------------------------------------------------------------------
# 7. zvm_after_init — bindings that vi-mode would otherwise clobber
#    zsh-vi-mode fires this hook after it resets all keymaps.
#    Source history-substring-search here so widgets exist at bind time.
# ------------------------------------------------------------------------------
zvm_after_init() {
  local _HSS="$HOME/.zsh/plugins/zsh-history-substring-search/zsh-history-substring-search.zsh"
  if [[ -f $_HSS ]]; then
    source "$_HSS"
    # viins: arrow keys and Ctrl-P/N
    bindkey -M viins '^[[A' history-substring-search-up
    bindkey -M viins '^[[B' history-substring-search-down
    bindkey -M viins '^P'   history-substring-search-up
    bindkey -M viins '^N'   history-substring-search-down
    # vicmd: j/k walk history in normal mode
    bindkey -M vicmd 'k'    history-substring-search-up
    bindkey -M vicmd 'j'    history-substring-search-down
  fi

  # Restore Ctrl-R for fuzzy history even in vi mode
  bindkey -M viins '^R' history-incremental-search-backward
  bindkey -M vicmd '^R' history-incremental-search-backward
}

# If vi-mode was not installed, define the bindings directly
if [[ ! -f "$HOME/.zsh/plugins/zsh-vi-mode/zsh-vi-mode.plugin.zsh" ]]; then
  bindkey '^R'    history-incremental-search-backward
  bindkey '^[[A'  up-line-or-history
  bindkey '^[[B'  down-line-or-history
fi

# ------------------------------------------------------------------------------
# 8. Optional tools (guarded — a missing binary is never fatal)
# ------------------------------------------------------------------------------
[[ -f ~/.fzf.zsh ]] && source ~/.fzf.zsh

if command -v zoxide >/dev/null 2>&1; then
  eval "$(zoxide init zsh)"
  alias cd='z'          # replace cd with zoxide
fi

command -v direnv  >/dev/null 2>&1 && eval "$(direnv hook zsh)"

# Starship overrides the prompt below — comment out if you prefer the built-in
if command -v starship >/dev/null 2>&1; then
  eval "$(starship init zsh)"
else
  # --------------------------------------------------------------------------
  # Built-in prompt (no binary deps, full git info + exit status)
  # --------------------------------------------------------------------------
  autoload -Uz colors && colors
  setopt PROMPT_SUBST

  _prompt_git_info() {
    local branch
    branch=$(git symbolic-ref --short HEAD 2>/dev/null) || return
    local dirty
    dirty=$(git status --porcelain 2>/dev/null)
    if [[ -n $dirty ]]; then
      print -n " %F{magenta}${branch}%f%F{red}✗%f"
    else
      print -n " %F{magenta}${branch}%f%F{green}✔%f"
    fi
  }

  precmd() { _last_exit=$?; }

  _prompt_exit_symbol() {
    [[ ${_last_exit:-0} -eq 0 ]] \
      && print -n "%F{green}❯%f" \
      || print -n "%F{red}❯%f"
  }

  PROMPT='%F{cyan}%n@%m%f %F{blue}%~%f$(_prompt_git_info) $(_prompt_exit_symbol) '
  RPROMPT='%F{240}%*%f'
fi

# ------------------------------------------------------------------------------
# 9a. Shell options
# ------------------------------------------------------------------------------
setopt AUTO_CD
setopt EXTENDED_GLOB
setopt INTERACTIVE_COMMENTS
setopt NO_BEEP
setopt LONG_LIST_JOBS
setopt CORRECT                # suggest corrections for mistyped commands
setopt COMBINING_CHARS        # handle combining Unicode characters correctly

# ------------------------------------------------------------------------------
# 9b. Aliases
# ------------------------------------------------------------------------------
# Navigation
alias ll='ls -lah --color=auto'
alias la='ls -A --color=auto'
alias l='ls -CF --color=auto'
alias cls='clear'
alias ..='cd ..'
alias ...='cd ../..'
alias ....='cd ../../..'

# Git
alias gs='git status'
alias gd='git diff'
alias gdc='git diff --cached'
alias gl='git log --oneline --graph --decorate --all'
alias gla='git log --oneline --graph --decorate --all --stat'
alias ga='git add'
alias gaa='git add --all'
alias gc='git commit -m'
alias gca='git commit --amend --no-edit'
alias gp='git pull'
alias gP='git push'
alias gPf='git push --force-with-lease'   # safer than --force
alias gb='git branch'
alias gco='git checkout'
alias gcb='git checkout -b'
alias grh='git reset --hard'
alias grs='git reset --soft'
alias gst='git stash'
alias gstp='git stash pop'
alias gstl='git stash list'
alias gclean='git clean -fd'
alias gdry='git clean -nfd'               # preview before gclean

# Search
alias grep='grep --color=auto'
alias rg='rg --hidden --smart-case'
alias fd='fd --hidden'

# System
alias ports='ss -tulnp'
alias psg='ps aux | grep -i'
alias mem='free -h'
alias dfh='df -h'
alias duh='du -sh * | sort -h'

# Safety nets
alias rm='rm -i'
alias cp='cp -i'
alias mv='mv -i'

# ------------------------------------------------------------------------------
# 9c. Functions
# ------------------------------------------------------------------------------

# Create a directory and cd into it
mkcd() {
  [[ -z $1 ]] && { echo "usage: mkcd <dir>"; return 1; }
  mkdir -p "$1" && cd "$1"
}

# Alias: take is an oh-my-zsh convention, keep it
take() { mkcd "$@"; }

# Jump to the git repo root
croot() {
  local root
  root=$(git rev-parse --show-toplevel 2>/dev/null) \
    || { echo "not a git repo"; return 1; }
  cd "$root"
}

# Archive extraction — handles every common format
extract() {
  [[ ! -f $1 ]] && { echo "File not found: $1"; return 1; }
  case $1 in
    *.tar.bz2)  tar xjf  "$1" ;;
    *.tar.gz)   tar xzf  "$1" ;;
    *.tar.xz)   tar xJf  "$1" ;;
    *.tar.zst)  tar --zstd -xf "$1" ;;
    *.tar)      tar xf   "$1" ;;
    *.tbz2)     tar xjf  "$1" ;;
    *.tgz)      tar xzf  "$1" ;;
    *.bz2)      bunzip2  "$1" ;;
    *.gz)       gunzip   "$1" ;;
    *.rar)      unrar x  "$1" ;;
    *.zip)      unzip    "$1" ;;
    *.Z)        uncompress "$1" ;;
    *.7z)       7z x     "$1" ;;
    *.zst)      zstd -d  "$1" ;;
    *)          echo "Unsupported format: $1"; return 1 ;;
  esac
}

# Quick HTTP server in current directory
serve() {
  local port=${1:-8000}
  python3 -m http.server "$port"
}

# Print a horizontal rule
hr() {
  local cols=${COLUMNS:-80}
  printf '%*s\n' "$cols" '' | tr ' ' '─'
}

# Show PATH entries one per line
pathlist() {
  echo "$PATH" | tr ':' '\n'
}

# git: open a repo's remote URL in the browser (Linux xdg-open)
grepo() {
  local url
  url=$(git remote get-url origin 2>/dev/null) \
    || { echo "no remote origin"; return 1; }
  url=${url/git@github.com:/https:\/\/github.com\/}
  url=${url%.git}
  xdg-open "$url" 2>/dev/null || echo "$url"
}

# ------------------------------------------------------------------------------
# 9d. Key bindings (applied after plugin hooks)
# ------------------------------------------------------------------------------
bindkey '^A'    beginning-of-line
bindkey '^E'    end-of-line
bindkey '^K'    kill-line
bindkey '^U'    backward-kill-line
bindkey '^W'    backward-kill-word
bindkey '^[[3~' delete-char            # Delete key
bindkey '^H'    backward-delete-char   # Backspace in some terminals

# ------------------------------------------------------------------------------
# Cache dir (for compinit)
# ------------------------------------------------------------------------------
[[ -d "$XDG_CACHE_HOME/zsh" ]] || mkdir -p "$XDG_CACHE_HOME/zsh/compcache"

# ------------------------------------------------------------------------------
# Local overrides — machine-specific, never committed
# ------------------------------------------------------------------------------
[[ -f ~/.zshrc.local ]] && source ~/.zshrc.local
