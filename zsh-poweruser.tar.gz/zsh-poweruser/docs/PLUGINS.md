# Plugin System

## Loading order contract

The order in `.zshrc` is not stylistic — each item has a hard dependency.

### 1. `fpath` mutations → `compinit`

`fpath` only registers directories where completion functions can be found.
It does not activate any code. All `fpath+=` calls must come before the single
`compinit` invocation. Running `compinit` twice in a session is a startup-time
penalty with no benefit.

```zsh
fpath+=("$HOME/.zsh/plugins/zsh-completions/src")
autoload -Uz compinit && compinit
```

### 2. `fast-syntax-highlighting` before `zsh-autosuggestions`

Syntax highlighting wraps the ZLE buffer update hooks. Autosuggestions attaches
to the same hooks. If autosuggestions loads first, the highlighter's hook
registration clobbers the suggestion rendering, producing visual glitches.

### 3. `ZVM_*` variables before `source zsh-vi-mode`

`zsh-vi-mode` reads configuration variables at plugin init time, not lazily.
Setting `ZVM_VI_INSERT_ESCAPE_BINDKEY=jk` after the `source` call is a silent
no-op.

```zsh
# CORRECT
ZVM_VI_INSERT_ESCAPE_BINDKEY=jk
source "$HOME/.zsh/plugins/zsh-vi-mode/zsh-vi-mode.plugin.zsh"

# BROKEN — variable set after init, ignored
source "$HOME/.zsh/plugins/zsh-vi-mode/zsh-vi-mode.plugin.zsh"
ZVM_VI_INSERT_ESCAPE_BINDKEY=jk   # too late
```

### 4. `zsh-history-substring-search` inside `zvm_after_init`

`zsh-vi-mode` calls `zvm_after_init` as the last step of its own
initialization, after resetting all keymaps. Any `bindkey` executed before
this hook fires gets silently overwritten.

The correct pattern sources `zsh-history-substring-search` (so its widgets
exist) and registers its bindings, all inside `zvm_after_init`:

```zsh
zvm_after_init() {
  source "$HOME/.zsh/plugins/zsh-history-substring-search/zsh-history-substring-search.zsh"
  bindkey -M viins '^[[A' history-substring-search-up
  bindkey -M viins '^[[B' history-substring-search-down
  bindkey -M vicmd 'k'    history-substring-search-up
  bindkey -M vicmd 'j'    history-substring-search-down
}
```

The explicit `-M viins` / `-M vicmd` targets are necessary because `bindkey`
without a keymap flag writes to the `main` keymap, which vi-mode does not use
for character input in either mode.

---

## Troubleshooting

**↑ arrow does not filter history by prefix**

The `history-substring-search-up` widget is not bound, or the binding was
set before `zvm_after_init` fired. Check that your `bindkey` calls are inside
the `zvm_after_init` function.

```zsh
# Confirm the widget exists:
zle -la | grep history-substring
```

**`jk` does not exit insert mode**

`ZVM_VI_INSERT_ESCAPE_BINDKEY` was set after `source zsh-vi-mode`. Move it
above the `source` line.

**Autosuggestions show no text**

Usually means `ZSH_AUTOSUGGEST_USE_ASYNC=1` combined with a terminal that
doesn't support async updates. Set it to `0` as a test:

```zsh
ZSH_AUTOSUGGEST_USE_ASYNC=0
```

**`compinit` security warning about insecure directories**

Debian sometimes has world-writable completion dirs. Run:

```bash
compaudit | xargs chmod g-w,o-w
```

Then remove `~/.zcompdump` and restart the shell.

**`fd` not found after `install.sh`**

On Debian the package is `fd-find` and the binary is `fdfind`. `install.sh`
creates the symlink at `/usr/local/bin/fd`. If the symlink is missing:

```bash
sudo ln -sf "$(command -v fdfind)" /usr/local/bin/fd
```

---

## Plugin locations

| Plugin | Source |
|---|---|
| `zsh-completions` | `~/.zsh/plugins/zsh-completions` |
| `zsh-autosuggestions` | `~/.zsh/plugins/zsh-autosuggestions` or `/usr/share/zsh/plugins/` |
| `fast-syntax-highlighting` | `~/.zsh/plugins/fast-syntax-highlighting` |
| `zsh-history-substring-search` | `~/.zsh/plugins/zsh-history-substring-search` |
| `zsh-vi-mode` | `~/.zsh/plugins/zsh-vi-mode` |

All are guarded with `[[ -f ... ]]` checks. A missing plugin is skipped
silently — the shell still starts cleanly.
