# Keybinding Reference

## Vi mode states

`zsh-vi-mode` gives the shell three modal states:

| Mode | Cursor | How to enter |
|---|---|---|
| INSERT | beam `\|` | start of every command; `i` from NORMAL |
| NORMAL | block `█` | `Esc` or `jk` |
| VISUAL | block `█` | `v` from NORMAL |

---

## Insert mode (`viins`)

| Binding | Action |
|---|---|
| `jk` | Switch to NORMAL mode |
| `Ctrl-A` | Beginning of line |
| `Ctrl-E` | End of line |
| `Ctrl-K` | Kill to end of line |
| `Ctrl-U` | Kill to beginning of line |
| `Ctrl-W` | Delete previous word |
| `Ctrl-H` | Backspace |
| `Delete` | Delete character under cursor |
| `Ctrl-R` | Incremental history search (fzf if installed) |
| `↑` | History substring search up (filtered by typed prefix) |
| `↓` | History substring search down |
| `Ctrl-P` | History substring search up |
| `Ctrl-N` | History substring search down |
| `Tab` | Open completion menu |

---

## Normal mode (`vicmd`)

| Binding | Action |
|---|---|
| `k` | History substring search up |
| `j` | History substring search down |
| `Ctrl-R` | Incremental history search |
| `0` | Beginning of line |
| `$` | End of line |
| `w` / `b` | Next / previous word |
| `dd` | Delete entire line |
| `cc` | Change entire line (back to INSERT) |
| `yy` | Yank line |
| `p` | Paste after cursor |
| `/` | Search forward in line |
| `u` | Undo |
| `Ctrl-R` | Redo |
| `v` | Enter VISUAL mode |

---

## Completion menu (`menuselect`)

| Binding | Action |
|---|---|
| `h` | Move left |
| `l` | Move right |
| `j` | Move down |
| `k` | Move up |
| `Enter` | Accept selection |
| `Esc` | Cancel menu |

---

## History substring search behaviour

Typing `git` then pressing `↑` walks backward through history showing only
entries that contain `git`. The match is prefix-anchored to the typed buffer,
not substring, which avoids false matches.

This only works correctly because the bindings are registered inside
`zvm_after_init`. If you add new bindings that vi-mode should not clobber,
add them there too.

---

## fzf bindings (when installed)

| Binding | Action |
|---|---|
| `Ctrl-R` | Fuzzy history search (replaces incremental) |
| `Ctrl-T` | Fuzzy file search, paste to command line |
| `Alt-C` | Fuzzy `cd` into directory |
